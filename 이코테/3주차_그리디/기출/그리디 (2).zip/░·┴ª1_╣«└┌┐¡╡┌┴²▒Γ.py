#문자열 뒤집기

s = input()
v = s[0]
z = 0
o = 0
if v == '0':
    o += 1
else:
    z += 1
for i in range(1, len(s)):
    if v != s[i] and v == '0':
        v = s[i]
        z += 1
    elif v != s[i] and v == '1':
        v = s[i]
        o += 1
print(min(z, o))