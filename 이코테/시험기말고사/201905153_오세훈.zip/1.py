# 정렬

l = [3, 1, 19, 7, 13, 11, 9, 17, 15, 5]
l.sort(reverse=True)
print(list(l))